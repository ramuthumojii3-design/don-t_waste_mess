# MessMeter — ZeroWaste Mess Hack

Hostel mess web app that cuts food waste: students see the weekly menu, skip meals 6 hours ahead,
rate dishes; the supervisor sees live headcount, raw-material quantities, waste logs and KPIs.

## Run (Express backend)

```bash
npm install
npm start          # http://localhost:3000
npm test           # 7 engine tests (cutoff, validation, scaling formula, NGO beacon, meal pass)
```

Data is saved in `data/db.json` (local JSON store: Hostels, Menus, Students, OptOuts,
FoodWasteLogs, DishRatings, Comments, Polls, NGOs). Delete that file to reset to the seed data.
You can still open `public/index.html` directly: it then falls back to an in-browser demo store.

## Login

Students: ID `S001` to `S050`, password `mess123`. Supervisor: `supervisor` / `mess@123`.
Change them with the `STUDENT_PASSWORD`, `SUPERVISOR_PASSWORD` and `JWT_SECRET` environment variables
(set them before the first run, because hashes are saved in `data/users.json`). Passwords are hashed with scrypt,
tokens are signed JWTs (8 hours), login is rate-limited, and students can only act as themselves.

## Structure

```text
server.js            Express REST API + JSON store + static hosting
public/engine.js     Business rules (cutoff, validation, scaling, NGO beacon). Used by server AND browser
public/seed.js       7-day menu (28 meals), 50 students, 14 days of waste + opt-out history, poll
public/script.js     UI: DOM, Fetch, Chart.js
public/index.html, style.css
test/engine.test.js  node:test unit tests
```

## API

`GET /api/state` · `POST /api/optout` · `/api/scan` · `/api/waste` · `/api/rating` · `/api/comment` · `/api/vote` · `/api/demo`

Every POST is validated on the server: meal and date format, student id, dish name, and the
6-hour cutoff, using the server clock in IST (`+05:30`). Ratings and comments open only after the meal starts.

## Known limits

- Without the Express server (opening `public/index.html` directly) there is no login: the "Viewing as" selector is a demo.
- All students' ratings are visible in the shared state; hide them behind per-user endpoints for production.
- NGO alerts and the meal-pass QR are simulations; no real NGO is contacted.
