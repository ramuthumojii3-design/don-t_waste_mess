const test = require("node:test"), assert = require("node:assert");
const MM = require("../public/engine.js"), { buildSeed } = require("../public/seed.js");
const day = n => new Date(Date.now() + n * 864e5 + 19800000).toISOString().slice(0, 10);
const mk = () => { const S = buildSeed(); return { S, e: MM.createEngine(S) }; };

test("opt-out accepted well before the 6-hour cutoff", () => {
  const { S, e } = mk(), r = e.handle("POST", "/api/optout", { student: 1, date: day(3), meal: "d", out: true });
  assert.equal(r.status, 200); assert.ok(S.optOuts[day(3) + "-d"].includes(1));
});
test("opt-out rejected after the meal has started / inside the cutoff", () => {
  const { e } = mk(); assert.equal(e.handle("POST", "/api/optout", { student: 1, date: day(-1), meal: "d", out: true }).status, 409);
});
test("unknown student, meal or date is rejected", () => {
  const { e } = mk();
  assert.equal(e.handle("POST", "/api/optout", { student: 999, date: day(3), meal: "d", out: true }).status, 400);
  assert.equal(e.handle("POST", "/api/optout", { student: 1, date: "bad", meal: "d", out: true }).status, 400);
  assert.equal(e.handle("POST", "/api/optout", { student: 1, date: day(3), meal: "x", out: true }).status, 400);
});
test("rating opens only after the meal starts, and unknown dishes are refused", () => {
  const { e } = mk();
  assert.equal(e.handle("POST", "/api/rating", { student: 1, date: day(3), meal: "d", dish: "Lauki kofta", stars: 5 }).status, 409);
  assert.equal(e.handle("POST", "/api/rating", { student: 1, date: day(-1), meal: "d", dish: "Lauki kofta", stars: 5 }).status, 200);
  assert.equal(e.handle("POST", "/api/rating", { student: 1, date: day(-1), meal: "d", dish: "__proto__", stars: 5 }).status, 400);
});
test("headcount scaling: 15 opt-outs take 50 -> 35 and rice 4.2 -> 2.94 kg", () => {
  const cook = (n, p) => n * p * MM.CFG.safety;
  assert.ok(Math.abs(cook(50, MM.CFG.portion.rice) - 4.2) < 1e-9);
  assert.ok(Math.abs(cook(35, MM.CFG.portion.rice) - 2.94) < 1e-9);
});
test("NGO beacon fires only when surplus is above 15 kg", () => {
  const { S, e } = mk(), w = s => e.handle("POST", "/api/waste", { date: day(-1), meal: "d", rice: 1, dal: 1, veg: 1, surplus: s });
  w(15); assert.equal(S.ngoAlerts.length, 0); w(15.5); assert.equal(S.ngoAlerts.length, 1);
});
test("meal pass shows opted-out students at the counter", () => {
  const { e } = mk(); e.handle("POST", "/api/optout", { student: 7, date: day(3), meal: "d", out: true });
  assert.equal(e.handle("POST", "/api/scan", { student: 7, date: day(3), meal: "d" }).data.result, "opted_out");
  assert.equal(e.handle("POST", "/api/scan", { student: 8, date: day(3), meal: "d" }).data.result, "valid");
});
test("ratings are stored as dated records", () => {
  const { S, e } = mk(), n = S.ratingLog.length;
  assert.ok(n >= 80 && S.ratingLog[0].date);
  e.handle("POST", "/api/rating", { student: 2, date: day(-1), meal: "d", dish: "Lauki kofta", stars: 4 });
  assert.equal(S.ratingLog.length, n + 1);
});
