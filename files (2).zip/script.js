// ================= Part 3: the app (DOM, Fetch, Chart.js) =================
"use strict";
const SEED=buildSeed();
const {MEALS,CFG,iso,startOf,createEngine}=MM;
const DAYS=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],ORDER=["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],ICON={b:"🌅",l:"🍛",s:"🫖",d:"🌙"};
const $=s=>document.querySelector(s),el=(t,c,h)=>{const e=document.createElement(t);if(c)e.className=c;if(h!=null)e.innerHTML=h;return e};
const esc=s=>String(s).replace(/[&<>]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;"}[c]));
const store={get(k,d){try{const v=localStorage.getItem("mm_"+k);return v?JSON.parse(v):d}catch(e){return d}},set(k,v){try{localStorage.setItem("mm_"+k,JSON.stringify(v))}catch(e){}}};
const toast=t=>{const e=$("#toast");e.textContent=t;e.classList.add("show");clearTimeout(toast.t);toast.t=setTimeout(()=>e.classList.remove("show"),2800)};
const fmt=m=>`${m.h%12||12}:${String(m.m).padStart(2,"0")} ${m.h<12?"AM":"PM"}`;
let S,me=1,remote=false,eng=null,selDay=new Date().getDay(),charts={},scanned="",skew=0,scanRes={};

// ---- Dietary tags and meal descriptions ----
const TAGS=[["High-protein",/\b(paneer|egg|chicken|fish|dal|rajma|chole|sprout|kadhi|sambar)\b/i],["Spicy",/\b(mirchi|curry|chole|biryani|rajma|manchurian|bhaji)\b/i],["Fried",/\b(pakora|samosa|bajji|puri|bhature|puff|fish fry)\b/i],["Light",/\b(curd|raita|lassi|salad|banana|upma|idli|chai|coffee|tea)\b/i]];
const tagsOf=ds=>[ds.every(d=>d[1])?"Veg":"Non-veg",...TAGS.filter(t=>ds.some(d=>t[1].test(d[0]))).map(t=>t[0])];
const pills=ts=>ts.map(t=>`<span class="pill ${t==="Veg"?"v":t==="Non-veg"?"nv":""}">${t}</span>`).join("");
const descOf=ds=>ds[0][0]+(ds.length>1?" served with "+ds.slice(1).map(d=>d[0].toLowerCase()).join(", "):"");
const dishHTML=d=>`<div class="dish"><i class="dot ${d[1]?"":"nv"}"></i>${d[0]}</div>`;

// ---- API: real Express backend if reachable, otherwise the same engine in the browser ----
const NOW=()=>Date.now()+skew;
const authH=()=>{const t=sessionStorage.getItem("mm_tok");return t?{Authorization:"Bearer "+t}:{}};
const logout=()=>{sessionStorage.clear();location.reload()};
const setS=s=>{S=s;if(s.serverNow)skew=s.serverNow-Date.now()};
async function call(m,p,b){
  if(remote){const r=await fetch(p,{method:m,headers:{"Content-Type":"application/json",...authH()},body:JSON.stringify(b)});if(r.status===401){logout();throw new Error("Please sign in.")}const j=await r.json();if(!r.ok)throw new Error(j.error);if(j.state)setS(j.state);return j}
  const r=eng.handle(m,p,b);if(r.status>=400)throw new Error(r.data.error);return r.data;
}
const act=async(p,b,msg)=>{try{await call("POST",p,b);if(msg)toast(msg);renderAll()}catch(e){toast(e.message)}};

// ---- Helpers ----
const dateFor=d=>{const t=new Date();t.setHours(0,0,0,0);t.setDate(t.getDate()+((d-t.getDay()+7)%7));return iso(t)};
const outsOf=(date,k)=>S.optOuts[date+"-"+k]||[];
const upcoming=n=>{const o=[],now=NOW(),t=new Date();t.setHours(0,0,0,0);for(let i=0;o.length<n;i++){const d=new Date(t);d.setDate(t.getDate()+i);MEALS.forEach(m=>{const date=iso(d);if(startOf(date,m.k)>now&&o.length<n)o.push({date,k:m.k,m,day:DAYS[d.getDay()]})})}return o};
const past=n=>{const o=[],now=NOW(),t=new Date();t.setHours(0,0,0,0);for(let i=0;o.length<n;i++){const d=new Date(t);d.setDate(t.getDate()-i);[...MEALS].reverse().forEach(m=>{const date=iso(d);if(startOf(date,m.k)<=now&&o.length<n)o.push({date,k:m.k,m,day:DAYS[d.getDay()]})})}return o};
const avg=n=>{const r=S.dishRatings[n];return r&&r[1]?r[0]/r[1]:0};
const css=v=>getComputedStyle(document.documentElement).getPropertyValue(v).trim();
function draw(id,cfg){if(charts[id])charts[id].destroy();Chart.defaults.color=css("--muted");charts[id]=new Chart($(id),cfg)}

// ---- Weekly menu ----
function renderWeek(){
  const tn=DAYS[new Date().getDay()];
  let h="<tr><th></th>"+ORDER.map(d=>`<th class="${d===tn?"today":""}">${d}</th>`).join("")+"</tr>";
  MEALS.forEach((m,i)=>{h+=`<tr><th>${ICON[m.k]} ${m.n}<br><span class="sub">${fmt(m)}</span></th>`+ORDER.map((d,j)=>{const ds=S.menus[d][m.k];return `<td class="${d===tn?"today":""}" style="animation-delay:${(i*7+j)*25}ms">${ds.map(dishHTML).join("")}<div>${pills(tagsOf(ds))}</div></td>`}).join("")+"</tr>"});
  $("#weekTable").innerHTML=h;
}

// ---- Daily menu: opt-out, ratings, comments ----
function renderDay(){
  const tn=DAYS[new Date().getDay()],chips=$("#dayChips");chips.innerHTML="";
  ORDER.forEach(d=>{const b=el("button","",d===tn?d+" · today":d);b.setAttribute("aria-pressed",DAYS.indexOf(d)===selDay);b.onclick=()=>{selDay=DAYS.indexOf(d);renderDay()};chips.append(b)});
  const date=dateFor(selDay),box=$("#dayMeals");box.innerHTML="";
  MEALS.forEach((m,i)=>{
    const ds=S.menus[DAYS[selDay]][m.k],out=outsOf(date,m.k).includes(me),open=startOf(date,m.k)-NOW()>=CFG.cutoffH*36e5,started=startOf(date,m.k)<=NOW(),c=el("div","card meal"+(out?" stamped":""));
    c.style.animationDelay=i*70+"ms";
    c.innerHTML=`<h3><span>${ICON[m.k]} ${m.n}</span><time>${date.slice(5)} · ${fmt(m)}</time></h3><p class="desc">${descOf(ds)}</p><div>${pills(tagsOf(ds))}</div>`;
    ds.forEach(([n,v])=>{
      const r=el("div","row");r.innerHTML=`<div class="dish"><i class="dot ${v?"":"nv"}"></i>${n}</div>`;
      const s=el("div","stars"),mine=S.myRatings[me+"|"+n]||0;
      for(let x=1;x<=5;x++){const b=el("button",x<=mine?"on":"","★");b.disabled=!started;b.setAttribute("aria-label",`Rate ${n} ${x} of 5`);b.onclick=()=>act("/api/rating",{student:me,dish:n,date,meal:m.k,stars:x},`Rated ${n}: ${x}/5`);s.append(b)}
      r.append(s);c.append(r)});
    const cm=el("div","cm",`<input type="text" placeholder="Comment on this meal" maxlength="200" aria-label="Comment">`),cb=el("button","","Send");
    cb.onclick=()=>act("/api/comment",{student:me,date,meal:m.k,text:cm.firstChild.value},"Feedback sent");cm.append(cb);cm.firstChild.disabled=cb.disabled=!started;c.append(cm);
    const sk=el("button","skip "+(out?"out":"primary"),out?(open?"✕ Opted out · tap to opt back in":"✕ Opted out · locked"):open?`Skip this meal · +₹${CFG.rebate} rebate`:"Cutoff passed");
    sk.disabled=!open;sk.onclick=()=>act("/api/optout",{student:me,date,meal:m.k,out:!out},out?"Opted back in":`Skipped. ₹${CFG.rebate} rebate credited`);
    c.append(sk);box.append(c)});
}

// ---- Digital meal pass ----
function renderPass(){
  const up=upcoming(8),sel=$("#passSel");
  if(!sel.options.length)up.forEach((u,i)=>sel.add(new Option(`${u.day} ${u.m.n} · ${u.date.slice(5)}`,i)));
  const u=up[+sel.value||0],out=outsOf(u.date,u.k).includes(me),stu=S.students[me-1],tag=u.date+u.k+me;
  let x=me*7919+(+u.date.replace(/\D/g,"")%99991)+u.k.charCodeAt(0),cells="";
  for(let i=0;i<49;i++){x^=x<<13;x^=x>>>17;x^=x<<5;cells+=`<i class="${x&1?"on":""}"></i>`}
  const res=scanned!==tag?`<p class="note">Tap “Scan”: the server checks this pass like the mess counter would.</p>`:scanRes.result==="opted_out"?`<div class="cross">✕</div><b style="color:var(--brand)">OPTED OUT. Do not serve.</b>`:`<div class="cross ok">✓</div><b class="ok">VALID. Enjoy your meal!</b>`;
  $("#passBox").innerHTML=`<div class="card pass"><div class="sub">MESSMETER MEAL PASS</div><h3 style="margin:4px 0">${stu.name}</h3><div class="sub">Room ${stu.room} · ID ${String(me).padStart(3,"0")}</div><div class="qr">${cells}</div><div>${ICON[u.k]} ${u.m.n} · ${u.day} ${u.date.slice(5)}</div>${res}${scanned===tag&&!scanRes.inShift?'<p class="note">Outside this meal’s shift window (demo scan).</p>':""}<button class="primary skip" id="scan">Scan at counter</button></div>`;
  $("#scan").onclick=async()=>{try{scanRes=await call("POST","/api/scan",{student:me,date:u.date,meal:u.k});scanned=tag;renderPass()}catch(e){toast(e.message)}};
}

// ---- Supervisor: predictor, scaling, waste logging, NGO beacon ----
function renderSup(){
  const en=S.hostels[0].enrolled,up=upcoming(8),cook=(n,p)=>(n*p*CFG.safety).toFixed(1),nd=up.find(u=>u.k==="d"),outs=outsOf(nd.date,"d").length,n=en-outs;
  $("#plate").style.setProperty("--p",n/en*100);$("#plateN").textContent=n;
  $("#supKpis").innerHTML=`<div class="card kpi"><b>${n}</b>Predicted dinner headcount (${nd.day})</div><div class="card kpi"><b>${outs}</b>Advance opt-outs</div><div class="card kpi"><b>${cook(n,CFG.portion.rice)} kg</b>Rice to cook (full house ${cook(en,CFG.portion.rice)} kg)</div><div class="card kpi"><b>₹${outs*CFG.cost}</b>Est. saved · ${(outs*CFG.avoidKg).toFixed(1)} kg waste prevented</div>`;
  $("#supTable").innerHTML="<tr><th>Meal</th><th>Opt-outs</th><th>Headcount</th><th>Rice kg</th><th>Dal kg</th><th>Veg kg</th></tr>"+up.map(u=>{const o=outsOf(u.date,u.k).length,h=en-o;return `<tr><td>${ICON[u.k]} ${u.day} ${u.m.n}</td><td>${o}</td><td><b>${h}</b></td><td>${cook(h,CFG.portion.rice)}</td><td>${cook(h,CFG.portion.dal)}</td><td>${cook(h,CFG.portion.veg)}</td></tr>`}).join("");
  $("#demo").textContent=outs>=15?"Reset demo":"Demo: 15 students opt out";
  $("#ngoBox").innerHTML=S.ngoAlerts.length?S.ngoAlerts.slice(0,3).map(a=>`<div class="ngo"><b>${a.kg} kg</b> surplus after ${a.date.slice(5)} ${MEALS.find(m=>m.k===a.meal).n}. Alerted: ${a.ngos.join(", ")} (verified, demo list)</div>`).join(""):`<p class="note">No alerts yet. Log more than ${CFG.ngoKg} kg of unserved surplus to fire the beacon.</p>`;
}

// ---- ZeroWaste KPI dashboard ----
function wasteByDay(){const m={};S.foodWasteLogs.forEach(l=>{const d=m[l.date]||(m[l.date]={rice:0,dal:0,veg:0});d.rice+=l.rice;d.dal+=l.dal;d.veg+=l.veg});return Object.keys(m).sort().map(k=>({date:k,...m[k],tot:m[k].rice+m[k].dal+m[k].veg}))}
function renderKpi(){
  const days=wasteByDay().slice(-14),sum=a=>a.reduce((s,d)=>s+d.tot,0),l7=sum(days.slice(-7)),p7=sum(days.slice(-14,-7)),pct=p7?(p7-l7)/p7*100:0;
  const outs=Object.values(S.optOuts).reduce((s,a)=>s+a.length,0),rs=Object.keys(S.dishRatings).map(n=>({n,a:avg(n)})).sort((a,b)=>b.a-a.a),top=rs.slice(0,5),low=rs.slice(-5).reverse(),show=[...top,...low];
  $("#kpiKpis").innerHTML=`<div class="card kpi"><b>${l7.toFixed(0)} kg</b>Waste, last 7 days (${pct>=0?"↓":"↑"} ${Math.abs(pct).toFixed(0)}% vs prior week)</div><div class="card kpi"><b>₹${outs*CFG.cost}</b>Saved via opt-outs (${outs} meals)</div><div class="card kpi"><b>${(outs*CFG.avoidKg).toFixed(1)} kg</b>Waste prevented</div><div class="card kpi"><b>₹${outs*CFG.rebate}</b>Rebates credited</div><div class="card kpi"><b>${top[0].n}</b>Top rated (${top[0].a.toFixed(1)}) · worst: ${low[0].n} (${low[0].a.toFixed(1)})</div>`;
  const lab=days.map(d=>d.date.slice(5)),grid={color:css("--line")};
  draw("#wasteLine",{type:"line",data:{labels:lab,datasets:[{data:days.map(d=>+d.tot.toFixed(1)),borderColor:css("--brand"),backgroundColor:css("--brand")+"33",fill:true,tension:.35}]},options:{maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true,grid},x:{grid:{display:false}}}}});
  const d7=days.slice(-7),ds=(l,k,c)=>({label:l,data:d7.map(d=>+d[k].toFixed(1)),backgroundColor:css(c),borderRadius:4});
  draw("#wasteBar",{type:"bar",data:{labels:d7.map(d=>d.date.slice(5)),datasets:[ds("Rice","rice","--brand"),ds("Dal","dal","--accent"),ds("Veg","veg","--veg")]},options:{maintainAspectRatio:false,scales:{x:{stacked:true,grid:{display:false}},y:{stacked:true,grid}}}});
  draw("#ratingChart",{type:"bar",data:{labels:show.map(x=>x.n),datasets:[{data:show.map(x=>+x.a.toFixed(2)),backgroundColor:show.map((x,i)=>i<5?css("--veg"):css("--brand")),borderRadius:6}]},options:{indexAxis:"y",maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{x:{min:0,max:5,grid},y:{grid:{display:false}}}}});
  const sv={};Object.entries(S.optOuts).forEach(([k,a])=>{const d=k.slice(0,10);sv[d]=(sv[d]||0)+a.length*CFG.cost});const sk=Object.keys(sv).sort().slice(-14);
  draw("#saveChart",{type:"bar",data:{labels:sk.map(d=>d.slice(5)),datasets:[{data:sk.map(d=>sv[d]),backgroundColor:css("--veg"),borderRadius:4}]},options:{maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true,grid},x:{grid:{display:false}}}}});
  $("#cmBox").innerHTML=S.comments.length?S.comments.slice(0,5).map(c=>`<div class="ngo"><b>${S.students[c.student-1].name}</b> on ${c.date.slice(5)} ${MEALS.find(m=>m.k===c.meal).n}: ${esc(c.text)}</div>`).join(""):`<p class="note">No comments yet. Add one from the Daily menu.</p>`;
}

// ---- Mess committee poll ----
function renderPoll(){
  const P=S.polls,tot=Object.values(P.votes).reduce((a,b)=>a+b,0),voted=P.voted.includes(me),box=$("#pollBox");
  box.innerHTML=`<h3 style="margin-top:0">${P.title}</h3>`+P.options.map(o=>{const v=P.votes[o]||0,p=tot?v/tot*100:0;return `<div style="margin:12px 0"><div style="display:flex;justify-content:space-between;gap:8px"><span>${o}</span><b>${v} · ${p.toFixed(0)}%</b></div><div class="bar"><i style="width:${p}%"></i></div><button data-o="${o}" ${voted?"disabled":""}>Vote</button></div>`}).join("")+`<p class="note">${voted?"You’ve voted. Thanks!":"One vote per student."} ${tot} votes cast.</p>`;
  box.querySelectorAll("button[data-o]").forEach(b=>b.onclick=()=>act("/api/vote",{student:me,option:b.dataset.o},"Vote counted"));
}

function renderAll(){
  const wal=Object.values(S.optOuts).filter(a=>a.includes(me)).length*CFG.rebate;
  $("#wallet").textContent=`Rebate wallet ₹${wal}`;
  renderWeek();renderDay();renderPass();renderSup();renderPoll();
  if($(".panel.on").id==="kpi")renderKpi();
}

// ---- Wiring ----
$("#tabs").onclick=e=>{const b=e.target.closest("button");if(!b)return;
  document.querySelectorAll("#tabs button").forEach(x=>x.setAttribute("aria-selected",x===b));
  document.querySelectorAll(".panel").forEach(p=>p.classList.toggle("on",p.id===b.dataset.p));
  if(b.dataset.p==="kpi")renderKpi()};
$("#who").onchange=e=>{me=+e.target.value;renderAll()};
$("#passSel").onchange=renderPass;
$("#demo").onclick=()=>{const nd=upcoming(8).find(u=>u.k==="d"),on=outsOf(nd.date,"d").length>=15;act("/api/demo",{date:nd.date,meal:"d",count:on?0:15},on?"Demo reset":"15 students opted out: 50 → 35")};
$("#logW").onclick=()=>{const s=$("#wMeal");s.innerHTML="";past(8).forEach(u=>s.add(new Option(`${u.day} ${u.m.n} · ${u.date.slice(5)}`,u.date+"|"+u.k)));$("#wd").showModal()};
$("#wCancel").onclick=()=>$("#wd").close();
$("#wSave").onclick=()=>{const[d,k]=$("#wMeal").value.split("|"),sur=+$("#wSur").value||0;$("#wd").close();act("/api/waste",{date:d,meal:k,rice:$("#wRice").value,dal:$("#wDal").value,veg:$("#wVeg").value,surplus:sur},sur>CFG.ngoKg?`Logged. ${sur} kg surplus: NGO beacon fired`:"Waste logged")};
$("#theme").onclick=()=>{const r=document.documentElement,dark=r.dataset.theme?r.dataset.theme==="dark":matchMedia("(prefers-color-scheme:dark)").matches;r.dataset.theme=dark?"light":"dark";store.set("theme",r.dataset.theme);renderAll()};
const sv=store.get("theme",null);if(sv)document.documentElement.dataset.theme=sv;

async function boot(){
  try{const r=await fetch("/api/state",{cache:"no-store",headers:authH()});
    if(/json/.test(r.headers.get("content-type")||"")){remote=true;if(r.status===401){$("#ld").showModal();return}if(r.ok)setS(await r.json())}}catch(e){}
  if(!remote){S=store.get("db",null)||SEED;eng=createEngine(S,s=>store.set("db",s))}
  const user=remote?JSON.parse(sessionStorage.getItem("mm_user")||"{}"):null;
  if(user){$("#signout").hidden=false;$("#signout").onclick=logout;
    if(user.role==="student"){me=user.sid;document.querySelector(".who").hidden=true;document.querySelector('[data-p="sup"]').hidden=true}}
  $("#who").innerHTML=S.students.map(s=>`<option value="${s.id}">${s.name} · ${s.room}</option>`).join("");$("#who").value=me;
  $("#hostel").textContent=`${S.hostels[0].name} · ${S.hostels[0].enrolled} enrolled · ${remote?"live Express API · "+(user.name||user.id):"offline demo store"}`;
  renderAll();
  if(remote&&!boot.p){boot.p=1;setInterval(async()=>{if(document.hidden)return;try{const r=await fetch("/api/state",{cache:"no-store",headers:authH()});if(r.status===401)return logout();if(r.ok){setS(await r.json());const id=$(".panel.on").id;if(id==="sup")renderSup();if(id==="kpi")renderKpi()}}catch(e){}},1e4)}
}
$("#ld").addEventListener("cancel",e=>e.preventDefault());
$("#lgo").onclick=async()=>{try{const r=await fetch("/api/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({id:$("#lid").value,password:$("#lpw").value})}),j=await r.json();
  if(!r.ok){$("#lerr").textContent=j.error;return}sessionStorage.setItem("mm_tok",j.token);sessionStorage.setItem("mm_user",JSON.stringify(j.user));$("#ld").close();boot()}catch(e){$("#lerr").textContent="Server not reachable."}};
$("#lpw").onkeydown=e=>{if(e.key==="Enter")$("#lgo").click()};
boot();
