// ================= Part 2: seed data (7-day menu: 1 = veg, 0 = non-veg; 50 students; 14 days of history) =================
function buildSeed(){
  const menus={Mon:{b:[["Poha",1],["Boiled egg",0],["Tea",1]],l:[["Steamed rice",1],["Dal tadka",1],["Aloo gobi",1]],s:[["Samosa",1],["Masala chai",1]],d:[["Chicken curry",0],["Chapati",1],["Jeera rice",1]]},Tue:{b:[["Idli sambar",1],["Coconut chutney",1]],l:[["Steamed rice",1],["Rajma",1],["Mixed raita",1]],s:[["Bread pakora",1],["Coffee",1]],d:[["Paneer butter masala",1],["Chapati",1],["Veg pulao",1]]},Wed:{b:[["Aloo paratha",1],["Curd",1]],l:[["Steamed rice",1],["Sambar",1],["Bhindi fry",1]],s:[["Veg puff",1],["Tea",1]],d:[["Egg curry",0],["Chapati",1],["Steamed rice",1]]},Thu:{b:[["Upma",1],["Banana",1]],l:[["Veg biryani",1],["Raita",1]],s:[["Mirchi bajji",1],["Tea",1]],d:[["Lauki kofta",1],["Chapati",1],["Dal fry",1]]},Fri:{b:[["Dosa",1],["Tomato chutney",1]],l:[["Steamed rice",1],["Chole",1],["Salad",1]],s:[["Corn chaat",1],["Lemon tea",1]],d:[["Fish fry",0],["Rice",1],["Dal",1]]},Sat:{b:[["Puri bhaji",1],["Tea",1]],l:[["Steamed rice",1],["Kadhi",1],["Aloo matar",1]],s:[["Pav bhaji",1]],d:[["Chicken fried rice",0],["Manchurian",1]]},Sun:{b:[["Chole bhature",1],["Lassi",1]],l:[["Chicken biryani",0],["Raita",1]],s:[["Sprout salad",1],["Tea",1]],d:[["Special: committee pick",1],["Gulab jamun",1]]}};
  const F=['Aarav','Vihaan','Ishaan','Rohan','Kabir','Ananya','Diya','Meera','Saanvi','Riya'],L=['Reddy','Sharma','Rao','Nair','Khan'];
  const students=Array.from({length:50},(_,i)=>({id:i+1,name:F[i%10]+' '+L[Math.floor(i/10)],room:'B-'+(101+i%25)}));
  const dishes=[...new Set(Object.values(menus).flatMap(d=>Object.values(d).flat().map(x=>x[0])))];
  const dishRatings={};dishes.forEach((n,i)=>{const c=8+(i*7)%14,a=2.2+((i*37)%28)/10;dishRatings[n]=[+(a*c).toFixed(1),c]});
  const logs=[];
  for(let o=14;o>=1;o--){const tot=46-(14-o)*1.5+((o*37)%5-2);['l','d'].forEach((k,j)=>{const t=tot/2+(j?1:-1);logs.push({daysAgo:o,meal:k,rice:+(t*.4).toFixed(1),dal:+(t*.25).toFixed(1),veg:+(t*.35).toFixed(1),surplus:+(t*.3).toFixed(1)})})}
  const hist=[];for(let o=14;o>=1;o--)['l','d'].forEach((k,j)=>hist.push({daysAgo:o,meal:k,ids:Array.from({length:4+(o*5+j*3)%9},(_,i)=>22+i)}));
  const ratingLog=[];for(let o=14;o>=1;o--)for(let i=0;i<6;i++)ratingLog.push({student:1+(o*5+i*7)%50,dish:dishes[(o*7+i*5)%dishes.length],stars:1+(o*3+i*2)%5,daysAgo:o});
  const options=['Hyderabadi dum biryani + mirchi ka salan','Paneer tikka + butter naan','Masala dosa night','Pav bhaji + pulao','Chole kulche + lassi'],counts=[9,6,8,4,3],votes={},voted=[];
  options.forEach((o,i)=>votes[o]=counts[i]);for(let id=21;id<=50;id++)voted.push(id);
  return{hostels:[{id:1,name:'Kaveri Hostel',enrolled:50}],menus,students,optOuts:{},histOptOuts:hist,ratingLog,foodWasteLogs:logs,dishRatings,myRatings:{},comments:[],
    polls:{title:'Vote: next Sunday’s special dinner',options,votes,voted},ngos:['Seva Food Rescue','Annapurna Meals Network'],ngoAlerts:[]};
}


if(typeof module!=="undefined"&&module.exports)module.exports={buildSeed};
