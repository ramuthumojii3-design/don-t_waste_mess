"use strict";
// Express REST API + local JSON store. Runs the SAME engine as the browser (public/engine.js),
// so the 6-hour cutoff and all validation are enforced with the SERVER clock.
const express = require("express"), fs = require("fs"), path = require("path"), crypto = require("crypto"), jwt = require("jsonwebtoken");
const MM = require("./public/engine.js"), { buildSeed } = require("./public/seed.js");

const FILE = path.join(__dirname, "data", "db.json");   // Hostels, Menus, Students, OptOuts, FoodWasteLogs, DishRatings...
let S; try { S = JSON.parse(fs.readFileSync(FILE, "utf8")); } catch (e) { S = buildSeed(); }
const save = s => { fs.mkdirSync(path.dirname(FILE), { recursive: true }); fs.writeFileSync(FILE + ".tmp", JSON.stringify(s)); fs.renameSync(FILE + ".tmp", FILE); };
const engine = MM.createEngine(S, save); save(S);

// ---- auth: users live in data/users.json (scrypt hashes), tokens are signed JWTs ----
const DIR = path.join(__dirname, "data"); fs.mkdirSync(DIR, { recursive: true });
const hash = (pw, salt) => crypto.scryptSync(pw, salt, 32).toString("hex");
const mkUser = (id, role, name, pw, sid) => { const salt = crypto.randomBytes(8).toString("hex"); return { id, role, name, sid, salt, hash: hash(pw, salt) }; };
let USERS; try { USERS = JSON.parse(fs.readFileSync(path.join(DIR, "users.json"), "utf8")); } catch (e) {
  USERS = [mkUser("supervisor", "supervisor", "Mess Supervisor", process.env.SUPERVISOR_PASSWORD || "mess@123")]
    .concat(S.students.map(s => mkUser("S" + String(s.id).padStart(3, "0"), "student", s.name, process.env.STUDENT_PASSWORD || "mess123", s.id)));
  fs.writeFileSync(path.join(DIR, "users.json"), JSON.stringify(USERS));
}
let SECRET = process.env.JWT_SECRET; if (!SECRET) { const f = path.join(DIR, "secret.txt"); try { SECRET = fs.readFileSync(f, "utf8"); } catch (e) { SECRET = crypto.randomBytes(32).toString("hex"); fs.writeFileSync(f, SECRET); } }
const tries = {};   // simple login rate limit: 10 attempts / minute / IP
const app = express();
app.disable("x-powered-by");
app.use(express.json({ limit: "10kb" }));
app.post("/api/login", (req, res) => {
  const ip = req.ip, t = Date.now(); tries[ip] = (tries[ip] || []).filter(x => t - x < 6e4);
  if (tries[ip].length >= 10) return res.status(429).json({ error: "Too many attempts. Try again in a minute." });
  tries[ip].push(t);
  const { id, password } = req.body || {}, u = USERS.find(x => x.id === String(id || "").trim().toUpperCase() || x.id === String(id || "").trim());
  if (!u || typeof password !== "string" || !crypto.timingSafeEqual(Buffer.from(hash(password, u.salt)), Buffer.from(u.hash))) return res.status(401).json({ error: "Wrong ID or password." });
  res.json({ token: jwt.sign({ id: u.id, role: u.role, sid: u.sid }, SECRET, { expiresIn: "8h" }), user: { id: u.id, role: u.role, name: u.name, sid: u.sid } });
});
app.use("/api", (req, res, next) => {
  try { req.user = jwt.verify((req.headers.authorization || "").replace(/^Bearer /, ""), SECRET); next(); } catch (e) { res.status(401).json({ error: "Please sign in." }); }
});
app.use("/api", (req, res, next) => {   // roles: students act only as themselves; supervisor-only actions are blocked for students
  const u = req.user, p = req.path;
  if (req.method === "POST") {
    if (u.role === "student") { if (p === "/waste" || p === "/demo" || p === "/scan") return res.status(403).json({ error: "Supervisor only." }); req.body = Object.assign({}, req.body, { student: u.sid }); }
    else if (["/optout", "/rating", "/comment", "/vote"].includes(p)) return res.status(403).json({ error: "Students only." });
  }
  next();
});
app.use("/api", (req, res) => { const r = engine.handle(req.method, "/api" + req.path, req.body); res.status(r.status).json(r.data); });
app.use(express.static(path.join(__dirname, "public")));
app.use((err, req, res, next) => res.status(400).json({ error: "Bad request" }));

const PORT = process.env.PORT || 3000;
if (require.main === module) app.listen(PORT, () => console.log("MessMeter running at http://localhost:" + PORT));
module.exports = app;
