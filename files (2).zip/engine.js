// ================= Part 1: backend engine (same logic the Express server uses) =================
(function(g){
const MEALS=[{k:"b",n:"Breakfast",h:7,m:30},{k:"l",n:"Lunch",h:12,m:30},{k:"s",n:"Snack",h:17,m:0},{k:"d",n:"Dinner",h:19,m:30}];
const CFG={cutoffH:6,tz:"+05:30",rebate:30,portion:{rice:.08,dal:.04,veg:.15},safety:1.05,cost:16,avoidKg:.33,ngoKg:15};
const pad=n=>String(n).padStart(2,"0"),iso=d=>d.getFullYear()+"-"+pad(d.getMonth()+1)+"-"+pad(d.getDate());
// meal start is fixed to the hostel timezone (IST), so server and phone agree on the cutoff
const startOf=(date,k)=>{const m=MEALS.find(x=>x.k===k);return m&&/^\d{4}-\d{2}-\d{2}$/.test(date||"")?new Date(date+"T"+pad(m.h)+":"+pad(m.m)+":00"+CFG.tz):new Date(NaN)};
const num=v=>Math.max(0,+v||0);
function createEngine(S,save){
  const ist=ms=>new Date(ms+19800000).toISOString().slice(0,10);
  S.foodWasteLogs.forEach(l=>{if(l.daysAgo!=null){l.date=ist(Date.now()-l.daysAgo*864e5);delete l.daysAgo}});
  (S.histOptOuts||[]).forEach(h=>{S.optOuts[ist(Date.now()-h.daysAgo*864e5)+"-"+h.meal]=h.ids});delete S.histOptOuts;
  S.ratingLog=S.ratingLog||[];S.ratingLog.forEach(r=>{if(r.daysAgo!=null){r.date=ist(Date.now()-r.daysAgo*864e5);delete r.daysAgo}});
  const bad=(s,e)=>({status:s,data:{error:e}});
  function handle(method,path,b){
    b=b||{};
    if(method==="GET"&&path==="/api/state")return{status:200,data:Object.assign({},S,{serverNow:Date.now()})};
    if(method!=="POST")return bad(404,"Not found");
    // ---- server-side validation: every request is checked here, never trusted from the browser ----
    const needMeal=["/api/optout","/api/demo","/api/waste","/api/rating","/api/comment","/api/scan"].includes(path),
      needStu=["/api/optout","/api/rating","/api/comment","/api/scan","/api/vote"].includes(path),
      ts=startOf(b.date,b.meal),now=Date.now(),key=b.date+"-"+b.meal;
    if(needMeal&&isNaN(ts))return bad(400,"Unknown meal");
    if(needStu&&!(Number.isInteger(b.student)&&b.student>=1&&b.student<=S.students.length))return bad(400,"Unknown student");
    // meal-pass check at the counter: red cross if the student opted out
    if(path==="/api/scan")return{status:200,data:{result:(S.optOuts[key]||[]).includes(b.student)?"opted_out":"valid",inShift:now>=ts-9e5&&now<=ts+72e5}};
    if(path==="/api/optout"){
      const t=startOf(b.date,b.meal);
      if(isNaN(t))return bad(400,"Unknown meal");
      // server-side timestamp validation: opt-outs close CFG.cutoffH hours before the meal
      if(t-Date.now()<CFG.cutoffH*36e5)return bad(409,"Cutoff passed: opt-outs must be submitted at least "+CFG.cutoffH+" hours before the meal starts.");
      const a=S.optOuts[key]||(S.optOuts[key]=[]),i=a.indexOf(b.student);
      if(b.out&&i<0)a.push(b.student);else if(!b.out&&i>=0)a.splice(i,1);
    }else if(path==="/api/demo"){
      const a=(S.optOuts[key]||[]).filter(id=>id>16||id<2);
      for(let id=2;id<2+(b.count|0);id++)a.push(id);
      S.optOuts[key]=a;
    }else if(path==="/api/waste"){
      if(ts>now)return bad(409,"Log waste only after the meal has started.");
      const l={date:b.date,meal:b.meal,rice:num(b.rice),dal:num(b.dal),veg:num(b.veg),surplus:num(b.surplus)};
      S.foodWasteLogs.push(l);
      if(l.surplus>CFG.ngoKg)S.ngoAlerts.unshift({date:l.date,meal:l.meal,kg:l.surplus,ngos:S.ngos,at:Date.now()});
    }else if(path==="/api/rating"){
      if(ts>now)return bad(409,"Rating opens when the meal starts.");
      if((S.optOuts[key]||[]).includes(b.student))return bad(409,"You skipped this meal, so it cannot be rated.");
      if(!Object.hasOwn(S.dishRatings,b.dish))return bad(400,"Unknown dish");
      const s=Math.min(5,Math.max(1,b.stars|0)),k=b.student+"|"+b.dish,prev=S.myRatings[k]||0,r=S.dishRatings[b.dish]||(S.dishRatings[b.dish]=[0,0]);
      r[0]+=s-prev;if(!prev)r[1]++;S.myRatings[k]=s;S.ratingLog.push({student:b.student,dish:b.dish,date:b.date,meal:b.meal,stars:s,at:now});
    }else if(path==="/api/comment"){
      if(ts>now||(S.optOuts[key]||[]).includes(b.student))return bad(409,"Comments open once the meal starts (not for skipped meals).");
      const t=String(b.text||"").trim().slice(0,200);if(!t)return bad(400,"Write a comment first.");
      S.comments.unshift({student:b.student,date:b.date,meal:b.meal,text:t,at:Date.now()});
    }else if(path==="/api/vote"){
      const P=S.polls;if(P.voted.includes(b.student))return bad(409,"You already voted.");
      if(!P.options.includes(b.option))return bad(400,"Unknown option");
      P.votes[b.option]=(P.votes[b.option]||0)+1;P.voted.push(b.student);
    }else return bad(404,"Not found");
    if(save)save(S);
    return{status:200,data:{state:Object.assign({},S,{serverNow:Date.now()})}};
  }
  return{handle};
}
const api={MEALS,CFG,iso,startOf,createEngine};
if(typeof module!=="undefined"&&module.exports)module.exports=api;else g.MM=api;
})(typeof window!=="undefined"?window:globalThis);
